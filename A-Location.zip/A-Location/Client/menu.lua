ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local open = false
local location = RageUI.CreateMenu("Location", "Choisissez votre véhicule")
local temps = RageUI.CreateSubMenu(location, "Location", "Choisissez la durée")
local choixTemps = 0
local TempsActiver = false
local choixVehicule = nil

function Payer()
    if choixVehicule and choixTemps > 0 then
        local TempsLocation = choixTemps
        TriggerServerEvent('Location:Paye', choixVehicule, TempsLocation)
    end
end

location.Closed = function()
    open = false
end

function MENULOCATION()
    open = true
    RageUI.Visible(location, true)

    CreateThread(function()
        while open do
            Wait(10)

            RageUI.IsVisible(location, function()

                RageUI.Button("Rhapsody", nil, {RightLabel = "250$ →"}, true, {
                    onSelected = function()
                        choixVehicule = "rhapsody"
                    end
                },temps)

                RageUI.Button("Panto", nil, {RightLabel = "200$ →"}, true, {
                    onSelected = function()
                        choixVehicule = "panto"
                    end
                },temps)
                
                RageUI.Button("Faggio", nil, {RightLabel = "150$ →"}, true, {
                    onSelected = function()
                        choixVehicule = "faggio"
                    end
                },temps)

            end)

            RageUI.IsVisible(temps, function()

                RageUI.Button("10 minutes", nil, {RightLabel = "→"}, true, {
                    onSelected = function()
                        choixTemps = 10
                        TempsActiver = true
                        SpawnLocation()
                        open = false
                    end
                })

                RageUI.Button("30 minutes", nil, {RightLabel = "+50$ →"}, true, {
                    onSelected = function()
                        choixTemps = 30
                        TempsActiver = true
                        SpawnLocation()
                        open = false
                    end
                })

                RageUI.Button("60 minutes", nil, {RightLabel = "+100$ →"}, true, {
                    onSelected = function()
                        choixTemps = 60
                        TempsActiver = true
                        SpawnLocation()
                        open = false
                    end
                })

            end)

        end
    end)
end

function SpawnLocation()
    if choixVehicule then
        local model = GetHashKey(choixVehicule)
        RequestModel(model)
        while not HasModelLoaded(model) do
            Wait(10)
        end
        local VehiculePrix = {
            ["rhapsody"] = 250, 
            ["panto"] = 200,   
            ["faggio"] = 150    
        }
        local Prix = VehiculePrix[choixVehicule]
        local TotalPrix = Prix
        if choixTemps == 30 then
            TotalPrix = Prix + 50
        elseif choixTemps == 60 then
            TotalPrix = Prix + 100
        end
        if ESX.GetPlayerData().money >= TotalPrix then
            Payer()
            local vehicle = CreateVehicle(model, -1034.58, -2729.74, 19.77, 239.99, true, false)
            TaskWarpPedIntoVehicle(PlayerPedId(), vehicle, -1)
            SetVehicleNumberPlateText(vehicle, "LOCATION")
            local TempsRestant = choixTemps * 60000 
            ESX.ShowNotification("Temps restant : " .. choixTemps .. " minute(s)")
            SetTimeout(TempsRestant, function()
                DeleteEntity(vehicle)
                ESX.ShowNotification("Fin de la location")
                TempsActiver = false 
            end)
        else
            ESX.ShowNotification("Vous n'avez pas assez d'argent pour la location du véhicule")
        end
    end
end

local position = {
    {x = -1038.25, y = -2731.83, z = 19.17, h = 191.6 }
}

Citizen.CreateThread(function()
    while true do
        Wait(10)
        for k in pairs(position) do
            local plyCoords = GetEntityCoords(PlayerPedId(), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, position[k].x, position[k].y, position[k].z)
            if dist <= 2.5 then
                ESX.ShowHelpNotification('Appuyez sur ~INPUT_CONTEXT~ pour accéder à la location.')
                if IsControlJustPressed(1, 51) then
                    if not open then 
                        MENULOCATION()
                    end
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    for k in pairs(position) do
        local blip = AddBlipForCoord(position[k].x, position[k].y, position[k].z, position[k].h)
        SetBlipSprite(blip, 280)
        SetBlipDisplay(blip, 4)
        SetBlipScale(blip, 0.8)
        SetBlipColour(blip, 0)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentSubstringPlayerName('Location')
        EndTextCommandSetBlipName(blip)
        CreatePedAndStartScenario("a_m_y_business_02", position[k].x, position[k].y, position[k].z, position[k].h)
    end
end)

function CreatePedAndStartScenario(hash, x, y, z, h)
    RequestModel(hash)
    while not HasModelLoaded(hash) do
        Wait(1000)
    end
    local ped = CreatePed(4, hash, x, y, z, h, 0.0, false, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true) 
    TaskStartScenarioInPlace(ped, "WORLD_HUMAN_CLIPBOARD", 0, true)
end

---

print("A-Dev : discord.gg/vmTt5sRdhQ") 
print("Pour toute demande d'aide concernant le script ou autre")
print("Location | Crée par AmieZ")