ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterNetEvent('Location:Paye')
AddEventHandler('Location:Paye', function(choixVehicule, TempsLocation)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    local VehiculePrix = {
        ["rhapsody"] = 250, 
        ["panto"] = 200,   
        ["faggio"] = 150    
    }
    local Prix = VehiculePrix[choixVehicule]
    local TotalPrix = Prix
    if TempsLocation == 30 then
        TotalPrix = Prix + 50
    elseif TempsLocation == 60 then
        TotalPrix = Prix + 100
    end
    xPlayer.removeMoney(TotalPrix)
    TriggerClientEvent('esx:showNotification', _source, "Vous avez payé " .. TotalPrix .. "$ pour la location du véhicule")
end)
